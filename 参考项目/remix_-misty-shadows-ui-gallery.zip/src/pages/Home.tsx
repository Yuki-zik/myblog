import { motion } from "motion/react";
import { Terminal, BookOpen, GitBranch, Cpu, Database, ArrowRight, Network } from "lucide-react";
import { Link } from "react-router-dom";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
  }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Home() {
  return (
    <main className="max-w-7xl mx-auto px-6 py-12 space-y-20">
      
      {/* Hero Section - Split Layout */}
      <motion.section 
        className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative"
        initial="initial"
        animate="animate"
        variants={staggerContainer}
      >
        {/* Left: Academic/Editorial Intro */}
        <motion.div className="lg:col-span-7 space-y-8" variants={fadeInUp}>
          <div className="space-y-4">
            <div className="flex items-center gap-3 font-mono text-xs text-blue-600 dark:text-blue-400 font-bold tracking-widest uppercase">
              <span className="w-2 h-2 bg-blue-600 dark:bg-blue-400 rounded-full shadow-[0_0_8px_rgba(37,99,235,0.5)]" />
              Vol. 24 — 持续构建中
            </div>
            <h1 className="font-serif text-5xl md:text-6xl text-slate-900 dark:text-white leading-[1.1] tracking-tight transition-colors duration-500">
              工程、架构 <br />
              <span className="italic text-slate-500 dark:text-slate-400 font-light">&</span> 偶尔的胡思乱想.
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl font-sans transition-colors duration-500">
              这里是我的数字自留地。记录系统设计、AI 探索，以及那些在深夜 Debug 时突然冒出的奇怪念头。追求高信噪比，拒绝无聊的复制粘贴。
            </p>
          </div>

          <div className="flex items-center gap-4 font-mono text-sm font-medium">
            <button className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 py-3 rounded-full hover:bg-blue-600 dark:hover:bg-blue-500 hover:text-white hover:shadow-lg hover:shadow-blue-500/25 transition-all flex items-center gap-2 hover:-translate-y-0.5">
              翻阅归档 <ArrowRight className="w-4 h-4" />
            </button>
            <button className="bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 px-6 py-3 rounded-full hover:bg-slate-50 dark:hover:bg-slate-700 hover:shadow-md transition-all flex items-center gap-2 hover:-translate-y-0.5">
              <GitBranch className="w-4 h-4" /> 查看源码
            </button>
          </div>
        </motion.div>

        {/* Right: Technical Visual (Terminal/Code Block) */}
        <div className="lg:col-span-5 sticky top-28 z-10">
          <motion.div className="soft-card p-1.5" variants={fadeInUp}>
            <div className="bg-slate-900 dark:bg-[#0f1423] h-full p-6 rounded-xl text-slate-300 font-mono text-sm leading-relaxed overflow-hidden relative shadow-inner border border-slate-800/50">
              <div className="flex items-center gap-2 mb-6 border-b border-slate-700/50 pb-4">
                <div className="w-3 h-3 rounded-full bg-rose-500/80 shadow-[0_0_8px_rgba(244,63,94,0.4)]" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80 shadow-[0_0_8px_rgba(245,158,11,0.4)]" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80 shadow-[0_0_8px_rgba(16,185,129,0.4)]" />
                <span className="ml-2 text-xs text-slate-500">daily_routine.rs</span>
              </div>
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <p><span className="text-blue-400">fn</span> <span className="text-emerald-400">survive_another_day</span>() -&gt; Result&lt;Day, Burnout&gt; {'{'}</p>
                <p className="pl-4 text-slate-500">// 注入灵魂燃料</p>
                <p className="pl-4"><span className="text-blue-400">let</span> <span className="text-blue-400">mut</span> coffee = Coffee::brew(Roast::Dark)?;</p>
                <p className="pl-4 mt-2 text-slate-500">// 试图写出完美的架构</p>
                <p className="pl-4"><span className="text-blue-400">let</span> code = Code::write().<span className="text-blue-400">await</span>;</p>
                <p className="pl-4 mt-2"><span className="text-blue-400">match</span> code.compile() {'{'}</p>
                <p className="pl-8">Ok(_) =&gt; println!(<span className="text-amber-300">"今天我是天才！"</span>),</p>
                <p className="pl-8">Err(e) =&gt; {'{'}</p>
                <p className="pl-12">println!(<span className="text-amber-300">"这破代码怎么又报错了: {}"</span>, e);</p>
                <p className="pl-12">coffee.refill();</p>
                <p className="pl-8">{'}'}</p>
                <p className="pl-4">{'}'}</p>
                <p className="pl-4 mt-2">Ok(Day::Survived)</p>
                <p>{'}'}</p>
                <div className="mt-4 flex items-center gap-2 text-emerald-400">
                  <span>$</span> 
                  <motion.span 
                    animate={{ opacity: [1, 0] }}
                    transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}
                    className="inline-block w-2 h-4 bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.8)]"
                  />
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </motion.section>

      {/* Research Domains - Strict Grid */}
      <motion.section
        initial="initial"
        whileInView="animate"
        viewport={{ once: true, margin: "-100px" }}
        variants={staggerContainer}
      >
        <motion.div variants={fadeInUp} className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4 mb-6 transition-colors duration-500">
          <h2 className="font-mono text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest">关注领域</h2>
          <span className="font-mono text-xs text-slate-500 dark:text-slate-400">04 活跃中</span>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { id: "01", title: "AI 工程化", desc: "让大模型干活的艺术：Prompt 调优、RAG 架构与 Agent 驯化指南。", icon: Cpu },
            { id: "02", title: "系统架构", desc: "分布式系统、数据库内核，以及如何应对高并发下的服务器哀嚎。", icon: Database },
            { id: "03", title: "知识管理", desc: "构建个人知识图谱，把散落的脑洞、碎片和灵感连接成网。", icon: Network },
            { id: "04", title: "疯狂造轮子", desc: "沉迷于开发各种提升效率（但可能没人用）的 CLI 工具和脚本。", icon: Terminal }
          ].map((domain) => (
            <motion.div variants={fadeInUp} key={domain.id} className="soft-card p-6 group cursor-pointer flex flex-col h-full">
              <div className="flex items-start justify-between mb-8">
                <domain.icon className="w-6 h-6 text-slate-400 dark:text-slate-500 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" />
                <span className="font-mono text-xs text-slate-300 dark:text-slate-600 group-hover:text-blue-300 dark:group-hover:text-blue-500 transition-colors">{domain.id}</span>
              </div>
              <h3 className="font-serif text-lg font-medium text-slate-900 dark:text-white mb-2 transition-colors duration-500">{domain.title}</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 font-sans leading-relaxed flex-grow transition-colors duration-500">{domain.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Featured Publication & Recent Notes */}
      <motion.section 
        className="grid grid-cols-1 lg:grid-cols-3 gap-8"
        initial="initial"
        whileInView="animate"
        viewport={{ once: true, margin: "-100px" }}
        variants={staggerContainer}
      >
        
        {/* Featured */}
        <motion.div variants={fadeInUp} className="lg:col-span-1 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4 transition-colors duration-500">
            <h2 className="font-mono text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest">近期得意之作</h2>
          </div>
          
          <Link to="/article/attention-is-all-you-need" className="block soft-card p-4 group cursor-pointer">
            <div className="relative w-full aspect-[4/3] mb-6">
              <img 
                src="https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=800&auto=format&fit=crop" 
                className="absolute inset-0 w-full h-full object-cover rounded-xl blur-2xl opacity-50 dark:opacity-40 translate-y-4 scale-95 group-hover:opacity-70 dark:group-hover:opacity-60 group-hover:translate-y-6 transition-all duration-500" 
                alt="" 
                referrerPolicy="no-referrer"
              />
              <img 
                src="https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=800&auto=format&fit=crop" 
                className="relative z-10 w-full h-full object-cover rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm group-hover:-translate-y-1 transition-transform duration-500" 
                alt="Abstract Tech" 
                referrerPolicy="no-referrer"
              />
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2 font-mono text-[10px] text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                <BookOpen className="w-3 h-3" /> 论文精读
              </div>
              <h3 className="font-serif text-xl font-medium text-slate-900 dark:text-white leading-snug group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                重读 Attention Is All You Need：那些年我们追过的 Transformer
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 font-sans line-clamp-2 transition-colors duration-500">
                抛开复杂的数学公式，用大白话聊聊 Transformer 是如何一步步统治 AI 世界的，以及它到底在“注意”些什么。
              </p>
            </div>
          </Link>
        </motion.div>

        {/* Recent Notes List */}
        <motion.div variants={fadeInUp} className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4 transition-colors duration-500">
            <h2 className="font-mono text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest">近期碎片</h2>
            <Link to="/" className="font-mono text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors flex items-center gap-1">
              查看全部 <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          <div className="space-y-3">
            {[
              { id: "api-idempotency", date: "2026-03-24", tag: "系统设计", title: "分布式 API 幂等性设计：如何防止用户疯狂点击提交按钮？" },
              { id: "react-server-components", date: "2026-03-20", tag: "前端架构", title: "React Server Components (RSC) 深度解析：前端架构的下一次范式转移" },
              { id: "css-variables-theming", date: "2026-03-15", tag: "CSS/UI", title: "现代 CSS 架构：用 CSS 变量构建可扩展的主题系统" },
              { id: "state-management", date: "2026-03-10", tag: "前端架构", title: "状态管理大乱斗：Redux 太重，Zustand 太轻，我该用啥？" },
              { id: "rust-borrow", date: "2026-03-05", tag: "RUST", title: "Rust 借用检查器：那个每天都在教我做人的严厉导师" }
            ].map((note, idx) => (
              <Link 
                to={["api-idempotency", "react-server-components", "css-variables-theming"].includes(note.id) ? `/article/${note.id}` : "#"}
                key={idx} 
              >
                <motion.div 
                  variants={fadeInUp}
                  className="group flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 p-5 soft-card cursor-pointer relative overflow-hidden mb-3"
                >
                  <div className="flex items-center gap-4 w-48 flex-shrink-0">
                    <span className="font-mono text-xs text-slate-400 dark:text-slate-500">{note.date}</span>
                    <span className="font-mono text-[10px] px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 group-hover:bg-blue-50 dark:group-hover:bg-blue-900/30 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {note.tag}
                    </span>
                  </div>
                  <h3 className="font-serif text-base text-slate-900 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors flex-grow pr-8">
                    {note.title}
                  </h3>
                  
                  {/* Hover Arrow Micro-interaction */}
                  <div className="absolute right-5 opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 text-blue-600 dark:text-blue-400">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </motion.div>
      </motion.section>
    </main>
  );
}
