import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, Clock, Calendar, Tag, ChevronRight } from 'lucide-react';
import { articles } from '../data/articles';

export default function ArticleView() {
  const { id } = useParams();
  const article = articles.find(a => a.id === id);
  const [activeId, setActiveId] = useState<string>("");

  // Intersection Observer for TOC highlighting
  useEffect(() => {
    if (!article) return;
    
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        });
      },
      { rootMargin: "-100px 0px -60% 0px" } // Trigger when heading is near the top
    );

    article.toc.forEach((item) => {
      const element = document.getElementById(item.id);
      if (element) observer.observe(element);
    });

    return () => observer.disconnect();
  }, [article]);

  if (!article) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-32 text-center">
        <h1 className="text-4xl font-serif font-bold text-slate-900 dark:text-white mb-4">文章未找到</h1>
        <Link to="/" className="text-blue-600 dark:text-blue-400 hover:underline flex items-center justify-center gap-2">
          <ArrowLeft className="w-4 h-4" /> 返回首页
        </Link>
      </div>
    );
  }

  return (
    <motion.main 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="max-w-7xl mx-auto px-6 py-12 lg:py-20"
    >
      <div className="mb-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm font-mono text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4" /> 返回花园
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start relative">
        
        {/* Left: Article Content */}
        <div className="lg:col-span-8 xl:col-span-9">
          <header className="mb-12 space-y-6">
            <div className="flex flex-wrap items-center gap-4 font-mono text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800/50 px-3 py-1.5 rounded-full">
                <Calendar className="w-3.5 h-3.5" /> {article.date}
              </span>
              <span className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800/50 px-3 py-1.5 rounded-full">
                <Clock className="w-3.5 h-3.5" /> {article.readTime}
              </span>
              <span className="flex items-center gap-1.5 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 px-3 py-1.5 rounded-full">
                <Tag className="w-3.5 h-3.5" /> {article.tag}
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white leading-tight tracking-tight">
              {article.title}
            </h1>
          </header>

          <div className="max-w-none">
            {article.content}
          </div>
          
          <div className="mt-20 pt-8 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
            <p className="font-mono text-sm text-slate-500">EOF</p>
            <button 
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="font-mono text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              返回顶部 ↑
            </button>
          </div>
        </div>

        {/* Right: Sticky TOC */}
        <div className="hidden lg:block lg:col-span-4 xl:col-span-3 sticky top-28">
          <div className="soft-card p-6">
            <h3 className="font-mono text-xs font-bold text-slate-900 dark:text-white uppercase tracking-widest mb-6 border-b border-slate-200 dark:border-slate-800 pb-4">
              目录 (TOC)
            </h3>
            <nav className="space-y-1">
              {article.toc.map((item) => (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`block py-2 text-sm font-sans transition-all duration-300 border-l-2 pl-4 ${
                    activeId === item.id 
                      ? "border-blue-500 text-blue-600 dark:text-blue-400 font-medium bg-blue-50/50 dark:bg-blue-900/10" 
                      : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
                  }`}
                  style={{ paddingLeft: `${item.level === 1 ? '1rem' : '2rem'}` }}
                >
                  {item.title}
                </a>
              ))}
            </nav>
          </div>
        </div>

      </div>
    </motion.main>
  );
}
