import React from 'react';

export interface TOCItem {
  id: string;
  title: string;
  level: number;
}

export interface Article {
  id: string;
  title: string;
  date: string;
  tag: string;
  readTime: string;
  toc: TOCItem[];
  content: React.ReactNode;
}

export const articles: Article[] = [
  {
    id: "attention-is-all-you-need",
    title: "重读 Attention Is All You Need：那些年我们追过的 Transformer",
    date: "2026-03-25",
    tag: "论文精读",
    readTime: "15 min read",
    toc: [
      { id: "intro", title: "1. 引言：RNN/CNN 的黄昏", level: 1 },
      { id: "self-attention", title: "2. Self-Attention：天涯若比邻", level: 1 },
      { id: "multi-head", title: "3. Multi-Head：多角度看世界", level: 2 },
      { id: "positional", title: "4. 位置编码：我到底在哪？", level: 1 },
      { id: "conclusion", title: "5. 结语：All You Need?", level: 1 },
    ],
    content: (
      <div className="space-y-6 text-slate-700 dark:text-slate-300 leading-relaxed text-lg">
        <p className="text-xl text-slate-500 dark:text-slate-400 italic mb-8">
          抛开复杂的数学公式，用大白话聊聊 Transformer 是如何一步步统治 AI 世界的，以及它到底在“注意”些什么。
        </p>

        <h2 id="intro" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">1. 引言：RNN/CNN 的黄昏</h2>
        <p>在 2017 年之前，NLP 领域几乎是 RNN（特别是 LSTM）和 CNN 的天下。RNN 的序列依赖性导致它无法并行计算，训练速度慢得令人发指；而 CNN 虽然能并行，但受限于卷积核大小，捕捉长距离依赖极其困难。</p>
        <p>直到 Google 团队抛出了这篇核弹级论文《Attention Is All You Need》，直接掀翻了桌子：<strong>不要 RNN，不要 CNN，只要注意力机制！</strong></p>

        <h2 id="self-attention" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">2. Self-Attention：天涯若比邻</h2>
        <p>Self-Attention 的核心思想是：在处理序列中的每一个词时，都去“看一眼”序列中的其他所有词，并根据它们的相关性分配不同的权重。</p>
        <div className="bg-slate-100 dark:bg-slate-800/50 p-6 rounded-xl border border-slate-200 dark:border-slate-700 font-mono text-sm my-8 overflow-x-auto shadow-inner">
          <span className="text-blue-500">Attention</span>(Q, K, V) = <span className="text-emerald-500">softmax</span>(QK<sup className="text-slate-400">T</sup> / √d_k)V
        </div>
        <p>这个公式极其优美。Q（Query）代表“我在找什么”，K（Key）代表“我有什么特征”，V（Value）代表“我的实际内容”。通过 Q 和 K 的点积，我们就能算出任意两个词之间的相关性（注意力分数）。</p>

        <h3 id="multi-head" className="text-xl font-serif font-bold text-slate-900 dark:text-white mt-8 mb-4 scroll-mt-24">3. Multi-Head：多角度看世界</h3>
        <p>单头注意力可能只会关注到一种维度的相关性（比如语法结构）。Multi-Head Attention 则是把 Q、K、V 投影到多个不同的子空间中，分别计算注意力，最后再拼接起来。这就像是找了多个专家，有的看语法，有的看语义，有的看情感，最后综合大家的意见。</p>

        <h2 id="positional" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">4. 位置编码：我到底在哪？</h2>
        <p>因为抛弃了 RNN，Transformer 失去了处理序列顺序的能力。对它来说，“我爱你”和“你爱我”是一样的词袋。为了解决这个问题，作者引入了 Positional Encoding（位置编码）。</p>
        <p>通过正弦和余弦函数，为每个位置生成一个独特的向量，并加到词向量上。这样，模型在计算注意力时，不仅能看到词的内容，还能感知到词的位置距离。</p>

        <h2 id="conclusion" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">5. 结语：All You Need?</h2>
        <p>回头看，这篇论文的标题极其狂妄，但也极其自信。它不仅统一了 NLP 领域，现在甚至在 CV（Vision Transformer）领域也大杀四方。Transformer 证明了：在海量数据和算力面前，简单、可高度并行的架构，才是通往 AGI 的康庄大道。</p>
      </div>
    )
  },
  {
    id: "api-idempotency",
    title: "分布式 API 幂等性设计：如何防止用户疯狂点击提交按钮？",
    date: "2026-03-24",
    tag: "系统设计",
    readTime: "8 min read",
    toc: [
      { id: "what", title: "1. 什么是幂等性？", level: 1 },
      { id: "why", title: "2. 为什么需要幂等？", level: 1 },
      { id: "how", title: "3. 常见幂等性方案", level: 1 },
      { id: "token", title: "3.1 Token 机制", level: 2 },
      { id: "db", title: "3.2 数据库唯一索引", level: 2 },
      { id: "statemachine", title: "3.3 状态机控制", level: 2 },
      { id: "summary", title: "4. 总结", level: 1 },
    ],
    content: (
      <div className="space-y-6 text-slate-700 dark:text-slate-300 leading-relaxed text-lg">
        <h2 id="what" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">1. 什么是幂等性？</h2>
        <p>在数学和计算机科学中，幂等操作的特点是其任意多次执行所产生的影响均与一次执行的影响相同。简单来说，对于同一个 API 接口，发起一次请求和发起多次重复请求，后端系统的数据状态应该是一致的。</p>

        <h2 id="why" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">2. 为什么需要幂等？</h2>
        <p>在分布式系统中，网络是不稳定的。常见的场景包括：</p>
        <ul className="list-disc pl-6 space-y-2 my-4">
          <li><strong>前端重复提交：</strong> 用户手抖，或者网络慢时疯狂点击“提交订单”按钮。</li>
          <li><strong>接口超时重试：</strong> 微服务之间调用超时，RPC 框架自动发起重试。</li>
          <li><strong>消息队列重复消费：</strong> MQ 无法保证 Exactly Once，可能会导致同一条消息被消费多次。</li>
        </ul>
        <p>如果没有幂等性保证，用户可能会被扣多次钱，或者生成多个相同的订单，这在业务上是灾难性的。</p>

        <h2 id="how" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">3. 常见幂等性方案</h2>

        <h3 id="token" className="text-xl font-serif font-bold text-slate-900 dark:text-white mt-8 mb-4 scroll-mt-24">3.1 Token 机制 (防重 Token)</h3>
        <p>这种方案常用于表单提交。流程如下：</p>
        <ol className="list-decimal pl-6 space-y-2 my-4">
          <li>客户端渲染表单前，先向后端请求一个唯一的 Token（存入 Redis）。</li>
          <li>客户端提交表单时，带上这个 Token。</li>
          <li>后端收到请求，去 Redis 中删除该 Token。如果删除成功，说明是第一次请求，放行；如果删除失败（Token 不存在），说明是重复请求，直接返回成功或提示重复提交。</li>
        </ol>

        <h3 id="db" className="text-xl font-serif font-bold text-slate-900 dark:text-white mt-8 mb-4 scroll-mt-24">3.2 数据库唯一索引</h3>
        <p>这是最简单粗暴但也最有效的方案之一。利用数据库的 Unique Key 来保证数据不会重复插入。</p>
        <p>例如，在创建订单时，我们可以将 <code>user_id</code> + <code>product_id</code> + <code>request_id</code> 作为唯一索引。如果有重复请求过来，数据库会抛出 <code>DuplicateKeyException</code>，我们在代码里捕获这个异常，当做成功处理即可。</p>

        <h3 id="statemachine" className="text-xl font-serif font-bold text-slate-900 dark:text-white mt-8 mb-4 scroll-mt-24">3.3 状态机控制</h3>
        <p>对于有状态流转的业务（如订单：待支付 -&gt; 支付中 -&gt; 已支付），可以在更新时带上状态条件。</p>
        <div className="bg-slate-100 dark:bg-slate-800/50 p-6 rounded-xl border border-slate-200 dark:border-slate-700 font-mono text-sm my-8 overflow-x-auto shadow-inner">
          <span className="text-blue-500">UPDATE</span> orders <span className="text-blue-500">SET</span> status = <span className="text-amber-500">'PAID'</span> <span className="text-blue-500">WHERE</span> order_id = 123 <span className="text-blue-500">AND</span> status = <span className="text-amber-500">'UNPAID'</span>;
        </div>
        <p>如果这条 SQL 返回的影响行数为 0，说明订单状态已经被改过了，直接忽略即可。这其实是一种乐观锁的实现。</p>

        <h2 id="summary" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">4. 总结</h2>
        <p>幂等性设计是高可用系统的基石。没有银弹，需要根据具体的业务场景（是强一致性要求，还是最终一致性要求？是高并发场景，还是低频操作？）来选择最合适的方案。通常，我们会组合使用多种方案，比如在网关层做 Token 防重，在底层数据库加唯一索引兜底。</p>
      </div>
    )
  },
  {
    id: "react-server-components",
    title: "React Server Components (RSC) 深度解析：前端架构的下一次范式转移",
    date: "2026-03-20",
    tag: "前端架构",
    readTime: "12 min read",
    toc: [
      { id: "intro", title: "1. 为什么我们需要 RSC？", level: 1 },
      { id: "what-is-rsc", title: "2. 什么是 React Server Components？", level: 1 },
      { id: "difference", title: "3. RSC vs SSR", level: 1 },
      { id: "benefits", title: "4. RSC 的核心优势", level: 1 },
      { id: "drawbacks", title: "5. 当前的局限与挑战", level: 1 },
      { id: "conclusion", title: "6. 总结", level: 1 },
    ],
    content: (
      <div className="space-y-6 text-slate-700 dark:text-slate-300 leading-relaxed text-lg">
        <p className="text-xl text-slate-500 dark:text-slate-400 italic mb-8">
          从 SPA 到 SSR，再到如今的 RSC，React 团队一直在探索如何在用户体验和开发体验之间找到完美的平衡点。RSC 究竟是炒作，还是真正的革命？
        </p>

        <h2 id="intro" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">1. 为什么我们需要 RSC？</h2>
        <p>传统的单页应用 (SPA) 存在一个致命的矛盾：为了提供丰富的交互，我们需要向客户端发送大量的 JavaScript 代码。这导致了首屏加载慢（尤其是低端设备）、SEO 困难，以及瀑布流式的数据获取问题。</p>
        <p>虽然服务端渲染 (SSR) 解决了首屏和 SEO 问题，但它仍然需要将所有的组件代码发送到客户端进行 Hydration（水合），这并没有从根本上减少客户端的 JS 体积。</p>

        <h2 id="what-is-rsc" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">2. 什么是 React Server Components？</h2>
        <p>RSC 允许我们在服务端直接渲染 React 组件，并且<strong>这些组件的代码永远不会被发送到客户端</strong>。客户端接收到的只是渲染后的 UI 描述（一种特殊的 JSON 格式）。</p>
        <p>这意味着你可以直接在组件里写数据库查询、读取文件系统，而不用担心暴露敏感信息或增加打包体积。</p>

        <h2 id="difference" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">3. RSC vs SSR</h2>
        <p>很多人容易把 RSC 和 SSR 搞混。简单来说：</p>
        <ul className="list-disc pl-6 space-y-2 my-4">
          <li><strong>SSR (Server-Side Rendering):</strong> 解决的是“初始加载”问题。它在服务端生成 HTML，但客户端依然需要下载对应的 JS 进行 Hydration。</li>
          <li><strong>RSC (React Server Components):</strong> 解决的是“代码体积”和“数据获取”问题。Server Components 永远留在服务端，只有 Client Components 才会发送到浏览器。</li>
        </ul>
        <p>两者不是互斥的，而是互补的。在 Next.js App Router 中，它们通常是一起使用的。</p>

        <h2 id="benefits" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">4. RSC 的核心优势</h2>
        <ol className="list-decimal pl-6 space-y-2 my-4">
          <li><strong>零客户端打包体积：</strong> 引入再大的服务端库（如 <code>marked</code> 或 <code>date-fns</code>），也不会增加客户端的 JS 负担。</li>
          <li><strong>直接访问后端资源：</strong> 无需编写 API 路由，直接在组件中查询数据库。</li>
          <li><strong>自动代码分割：</strong> 客户端组件按需加载，无需手动配置 <code>React.lazy</code>。</li>
        </ol>

        <h2 id="drawbacks" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">5. 当前的局限与挑战</h2>
        <p>当然，RSC 也引入了新的复杂性。开发者需要时刻清楚哪些是 Server Component，哪些是 Client Component。Server Component 不能使用 <code>useState</code>、<code>useEffect</code> 等客户端 Hook，也不能绑定事件监听器（如 <code>onClick</code>）。</p>

        <h2 id="conclusion" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">6. 总结</h2>
        <p>RSC 代表了 React 架构的一次重大演进。它打破了客户端和服务端的物理界限，让我们可以用一种统一的组件化思维来构建全栈应用。虽然学习曲线陡峭，但它带来的性能和开发体验提升是不可忽视的。</p>
      </div>
    )
  },
  {
    id: "css-variables-theming",
    title: "现代 CSS 架构：用 CSS 变量构建可扩展的主题系统",
    date: "2026-03-15",
    tag: "CSS/UI",
    readTime: "6 min read",
    toc: [
      { id: "intro", title: "1. 告别硬编码", level: 1 },
      { id: "basics", title: "2. CSS 变量基础", level: 1 },
      { id: "theming", title: "3. 构建暗黑模式", level: 1 },
      { id: "tailwind", title: "4. 结合 Tailwind CSS", level: 1 },
      { id: "summary", title: "5. 最佳实践", level: 1 },
    ],
    content: (
      <div className="space-y-6 text-slate-700 dark:text-slate-300 leading-relaxed text-lg">
        <h2 id="intro" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">1. 告别硬编码</h2>
        <p>在过去，我们通常使用 Sass 或 Less 的预处理器变量来管理颜色和间距。但预处理器变量在编译后就变成了静态的 CSS 值，无法在运行时动态修改。这使得实现诸如“暗黑模式”或“用户自定义主题”变得非常繁琐（通常需要切换不同的 CSS 文件或添加大量的覆盖类）。</p>

        <h2 id="basics" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">2. CSS 变量基础</h2>
        <p>CSS 自定义属性（俗称 CSS 变量）彻底改变了这一现状。它们存在于 DOM 中，可以被 JavaScript 读取和修改，并且遵循 CSS 的级联规则。</p>
        <div className="bg-slate-100 dark:bg-slate-800/50 p-6 rounded-xl border border-slate-200 dark:border-slate-700 font-mono text-sm my-8 overflow-x-auto shadow-inner">
<pre className="text-slate-800 dark:text-slate-200">
<code>{`:root {
  --primary-color: #3b82f6;
  --bg-color: #ffffff;
  --text-color: #1e293b;
}

body {
  background-color: var(--bg-color);
  color: var(--text-color);
}`}</code>
</pre>
        </div>

        <h2 id="theming" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">3. 构建暗黑模式</h2>
        <p>利用 CSS 变量，实现暗黑模式变得异常简单。我们只需要在特定的作用域（比如 <code>.dark</code> 类）下重新定义这些变量即可：</p>
        <div className="bg-slate-100 dark:bg-slate-800/50 p-6 rounded-xl border border-slate-200 dark:border-slate-700 font-mono text-sm my-8 overflow-x-auto shadow-inner">
<pre className="text-slate-800 dark:text-slate-200">
<code>{`.dark {
  --bg-color: #0f172a;
  --text-color: #f8fafc;
}`}</code>
</pre>
        </div>
        <p>当我们在 <code>&lt;html&gt;</code> 标签上切换 <code>dark</code> 类时，所有使用了这些变量的元素都会自动更新，无需任何额外的 CSS 覆盖。</p>

        <h2 id="tailwind" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">4. 结合 Tailwind CSS</h2>
        <p>在现代前端开发中，将 CSS 变量与 Tailwind CSS 结合是构建设计系统的最佳实践。我们可以在 Tailwind 的配置中引用 CSS 变量，从而既享受了 Tailwind 的实用工具类，又保留了 CSS 变量的动态特性。</p>

        <h2 id="summary" className="text-2xl font-serif font-bold text-slate-900 dark:text-white mt-12 mb-4 scroll-mt-24">5. 最佳实践</h2>
        <ul className="list-disc pl-6 space-y-2 my-4">
          <li><strong>语义化命名：</strong> 不要使用 <code>--blue-500</code>，而是使用 <code>--color-primary</code> 或 <code>--bg-surface</code>。变量名应该描述其用途，而不是其具体的值。</li>
          <li><strong>分层设计：</strong> 建立全局变量（调色板）和组件级变量（特定组件的颜色），组件级变量引用全局变量。</li>
          <li><strong>提供回退值：</strong> <code>var(--primary, #000)</code> 可以防止变量未定义时导致的样式崩溃。</li>
        </ul>
      </div>
    )
  }
];
