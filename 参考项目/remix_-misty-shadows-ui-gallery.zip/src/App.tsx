import { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { motion } from "motion/react";
import { Search, Github, Twitter, Rss, Mail, Moon, Sun } from "lucide-react";

import Home from "./pages/Home";
import ArticleView from "./pages/ArticleView";

export default function App() {
  const [isDark, setIsDark] = useState(false);

  // Toggle Dark Mode
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  return (
    <BrowserRouter>
      <div className="min-h-screen tech-grid relative font-sans text-slate-800 dark:text-slate-200 transition-colors duration-500 overflow-x-hidden">
        
        {/* 1. Subtle Film Grain (物理胶片噪点) */}
        <div 
          className="pointer-events-none fixed inset-0 z-50 opacity-[0.08] dark:opacity-[0.15]" 
          style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.8%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}
        ></div>

        {/* 2. Ambient Gradient Orbs (动态氛围光晕) */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <motion.div 
            animate={{ 
              scale: [1, 1.1, 1], 
              opacity: [0.6, 0.8, 0.6],
              x: [0, 50, 0],
              y: [0, -30, 0]
            }}
            transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-blue-400/40 dark:bg-blue-600/40 blur-[80px]" 
          />
          <motion.div 
            animate={{ 
              scale: [1, 1.2, 1], 
              opacity: [0.5, 0.7, 0.5],
              x: [0, -40, 0],
              y: [0, 40, 0]
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            className="absolute bottom-[-10%] right-[-10%] w-[40vw] h-[40vw] rounded-full bg-amber-400/40 dark:bg-purple-600/40 blur-[80px]" 
          />
        </div>

        {/* Main Content Wrapper (z-10 to sit above orbs) */}
        <div className="relative z-10">
          {/* Top Navigation */}
          <header className="sticky top-0 z-50 bg-[#F7F7F5]/80 dark:bg-[#0B0F19]/80 backdrop-blur-xl border-b border-slate-200/60 dark:border-slate-800/60 transition-colors duration-500">
            <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
              <Link to="/" className="flex items-center gap-4 group">
                <div className="w-8 h-8 bg-slate-900 dark:bg-white text-white dark:text-slate-900 flex items-center justify-center font-mono font-bold text-sm rounded-xl transition-colors duration-500 group-hover:scale-105">
                  ZNK
                </div>
                <span className="font-serif text-xl font-medium tracking-tight text-slate-900 dark:text-white transition-colors duration-500">
                  数字花园
                </span>
              </Link>

              <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600 dark:text-slate-400">
                <Link to="/" className="text-blue-600 dark:text-blue-400">深度长文</Link>
                <Link to="/" className="hover:text-slate-900 dark:hover:text-white transition-colors">系统架构</Link>
                <Link to="/" className="hover:text-slate-900 dark:hover:text-white transition-colors">灵感碎片</Link>
                <Link to="/" className="hover:text-slate-900 dark:hover:text-white transition-colors">关于我</Link>
              </div>

              <div className="flex items-center gap-3">
                {/* 3. Dark Mode Toggle */}
                <button 
                  onClick={() => setIsDark(!isDark)}
                  className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                >
                  {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                </button>

                <div className="hidden md:flex items-center bg-white dark:bg-slate-900/50 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 focus-within:border-blue-400 dark:focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-50 dark:focus-within:ring-blue-900/20 transition-all shadow-sm">
                  <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 mr-2" />
                  <input 
                    type="text" 
                    placeholder="搜索笔记..." 
                    className="bg-transparent border-none outline-none text-sm w-32 placeholder:text-slate-400 dark:placeholder:text-slate-500 font-mono text-xs text-slate-900 dark:text-white"
                  />
                  <kbd className="text-[10px] font-mono text-slate-400 dark:text-slate-500 ml-2 border border-slate-200 dark:border-slate-700 px-1 rounded bg-white dark:bg-slate-800">⌘K</kbd>
                </div>
              </div>
            </div>
          </header>

          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/article/:id" element={<ArticleView />} />
          </Routes>

          {/* Elegant Footer */}
          <footer className="border-t border-slate-200/60 dark:border-slate-800/60 bg-white/50 dark:bg-[#0B0F19]/50 backdrop-blur-sm mt-20 transition-colors duration-500">
            <div className="max-w-7xl mx-auto px-6 py-12">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
                
                {/* Brand & Copyright */}
                <div className="space-y-2 text-center md:text-left">
                  <div className="flex items-center justify-center md:justify-start gap-2 text-slate-900 dark:text-white font-serif font-medium transition-colors duration-500">
                    <div className="w-6 h-6 bg-slate-900 dark:bg-white text-white dark:text-slate-900 flex items-center justify-center font-mono font-bold text-[10px] rounded-sm transition-colors duration-500">
                      ZNK
                    </div>
                    数字花园
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-500 font-mono">
                    © {new Date().getFullYear()} ZNK. All rights reserved.
                  </p>
                </div>

                {/* Geek Quote */}
                <div className="text-center">
                  <p className="font-serif italic text-sm text-slate-400 dark:text-slate-500">
                    "Talk is cheap. Show me the code."
                  </p>
                </div>

                {/* Social Links */}
                <div className="flex items-center justify-center md:justify-end gap-4">
                  <a href="#" className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                    <Github className="w-4 h-4" />
                  </a>
                  <a href="#" className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                    <Twitter className="w-4 h-4" />
                  </a>
                  <a href="#" className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                    <Mail className="w-4 h-4" />
                  </a>
                  <a href="#" className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                    <Rss className="w-4 h-4" />
                  </a>
                </div>

              </div>
            </div>
          </footer>
        </div>
      </div>
    </BrowserRouter>
  );
}
